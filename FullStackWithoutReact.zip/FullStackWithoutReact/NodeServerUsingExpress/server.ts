// const express = require('express')
import express from 'express'
// const mongoose = require('mongoose')
import mongoose from 'mongoose'
import cors from 'cors';
import env from 'dotenv';
import {router} from './bookHandler';
env.config();
const url  = `mongodb+srv://${process.env.db_user}:${process.env.db_pass}@${process.env.db_server}/BookManagement?retryWrites=true&w=majority`;

const app = express()

mongoose.connect(url, {useNewUrlParser:true})
const con = mongoose.connection

con.on('open', () => {
    console.log('connected...')
})

app.use(cors());
app.use(express.json());

// const bookRouter = require('./bookHandler')
app.use('/books',router)

app.listen(8000, () => {
    console.log('Server started')
})