"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// const express = require('express')
var express_1 = __importDefault(require("express"));
// const mongoose = require('mongoose')
var mongoose_1 = __importDefault(require("mongoose"));
var cors_1 = __importDefault(require("cors"));
var dotenv_1 = __importDefault(require("dotenv"));
var bookHandler_1 = require("./bookHandler");
dotenv_1.default.config();
var url = "mongodb+srv://" + process.env.db_user + ":" + process.env.db_pass + "@" + process.env.db_server + "/BookManagement?retryWrites=true&w=majority";
var app = express_1.default();
mongoose_1.default.connect(url, { useNewUrlParser: true });
var con = mongoose_1.default.connection;
con.on('open', function () {
    console.log('connected...');
});
app.use(cors_1.default());
app.use(express_1.default.json());
// const bookRouter = require('./bookHandler')
app.use('/books', bookHandler_1.router);
app.listen(8000, function () {
    console.log('Server started');
});
