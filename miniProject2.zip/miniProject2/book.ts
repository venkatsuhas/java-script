
export class Book{
    bookId:string;
    title:string;
    author:string;
    rating:string;

    constructor(bookId:string,title:string,author:string,rating:string)
    {
        this.bookId=bookId;
        this.title=title;
        this.author=author;
        this.rating=rating;

    }

}
