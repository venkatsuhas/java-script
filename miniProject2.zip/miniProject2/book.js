var Book = /** @class */ (function () {
    function Book(bookId, title, author, rating) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.rating = rating;
    }
    return Book;
}());
export { Book };
