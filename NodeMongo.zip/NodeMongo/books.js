const mongoose=require('mongoose');

let bookSchema=mongoose.Schema({
    id:String,
    title:String,
    author:String,
    rating:Number,
    price:Number
})
module.exports=mongoose.model('books',bookSchema);