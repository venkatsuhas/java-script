const MongoClient = require('mongodb').MongoClient;
const env=require('dotenv');
env.config();
// const uri = `mongodb+srv://suhasnunepalli:Sree@0722@cluster0.l07lp.mongodb.net/BookManagement?retryWrites=true&w=majority`;
const uri = `mongodb+srv://${process.env.db_user}:${process.env.db_pass}@${process.env.db_server}/BookManagement?retryWrites=true&w=majority`;
const client = new MongoClient(uri);
const dbName = "BookManagement";
async function run(){
    try{
        await client.connect();
        console.log("connected to db!");
        const db = client.db(dbName);
        const row = db.collection('books');
        // const insert = await row.insertMany([
        //     {"id":"13","title":"pirates","author":"jack","rating":8,"price":6000}
        // ]);
                 
        // const filter = {id:'13'};
        // const option = {upsert:true};
        // const update={
        //     $set:{author:"sparrow"}
        // };
        // const updateDoc = await row.updateOne(filter,update,option);

        const mydocs = await row.find({"author":"sparrow"});
        mydocs.forEach(elem=>{
            console.log(elem);
        })
        // res.end(mydocs)
    }
    catch(err){
        console.log(err);
    }
    finally{
        await client.close();
    }
}
run();