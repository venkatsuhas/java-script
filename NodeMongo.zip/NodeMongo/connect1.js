const mongoose=require('mongoose');
const book=require('./books');
const uri = `mongodb+srv://${db_user}:${db_pass}@${db_server}/BookManagement?retryWrites=true&w=majority`;
mongoose.connect(uri,{
    useNewUrlParser:true,
    useUnifiedTopology:true
}).then(res=>console.log("Connected to mongoose db"));
