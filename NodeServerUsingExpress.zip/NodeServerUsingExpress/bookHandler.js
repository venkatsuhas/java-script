"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
const express = require('express');
const router = express.Router();
const book = require('./bookModel');
router.get('/', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const books = yield book.find();
        res.json(books);
    }
    catch (err) {
        res.send('Error ' + err);
    }
}));
router.get('/:id', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const books = yield book.findById(req.params.id);
        res.json(books);
    }
    catch (err) {
        res.send('Error ' + err);
    }
}));
router.post('/', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const books = new book({
        // console.log("hii");
        title: req.body.title,
        author: req.body.author,
        rating: req.body.rating,
        price: req.body.price
    });
    try {
        // console.log("hii");
        const a1 = yield books.save();
        // console.log("hello");
        res.json(a1);
    }
    catch (err) {
        res.send('Error');
    }
}));
router.patch('/:id', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const books = yield book.findById(req.params.id);
        if (req.body.title)
            books.title = req.body.title;
        if (req.body.author) {
            console.log("hii");
            books.author = req.body.author;
        }
        if (req.body.rating)
            books.rating = req.body.rating;
        if (req.body.price)
            books.price = req.body.price;
        const a1 = yield books.save();
        res.json(a1);
    }
    catch (err) {
        res.send('Error');
    }
}));
router.delete('/:id', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const books = yield book.findById(req.params.id);
        // books.sub = req.body.sub
        const a1 = yield books.remove();
        res.json(a1);
    }
    catch (err) {
        res.send('Error');
    }
}));
module.exports = router;
