"use strict";
const mon = require('mongoose');
// import mongoose from 'mongoose';
const bookSchema = new mon.Schema({
    title: {
        type: String,
        required: true
    },
    author: {
        type: String,
        required: true
    },
    rating: {
        type: String,
        required: true
    },
    price: {
        type: String,
        required: true
    }
});
module.exports = mon.model('book', bookSchema);
