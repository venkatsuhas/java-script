"use strict";
const express = require('express');
const mongoose = require('mongoose');
const url = `mongodb+srv://suhasnunepalli:Sree@0722@cluster0.l07lp.mongodb.net/BookManagement?retryWrites=true&w=majority`;
const app = express();
mongoose.connect(url, { useNewUrlParser: true });
const con = mongoose.connection;
con.on('open', () => {
    console.log('connected...');
});
app.use(express.json());
const bookRouter = require('./bookHandler');
app.use('/bookHandler', bookRouter);
app.listen(8000, () => {
    console.log('Server started');
});
