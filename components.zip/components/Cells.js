//import React from 'react'
import React, { Component } from 'react'

class _BoardCell extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             value:'_'
        }
    }

    onCellClick=()=>{
        console.log('cell clicked',this.props.id);
      //  value='o';
    //    console.log('value changed ',value);
       let newValue=this.state.value==='O'?'X':'O';
       this.setState({value:newValue});
       console.log('current state',this.state);
    }
    
    render() {
        return (
            <button onClick={this.onCellClick} 
            className='cell'>{this.state.value}</button> 
     );
      
    }
}


function BoardCell(props) {
    //let value='_';

    let style={
        color:props.value?'black':'transparent'
    }
let value=props.value|| '_' ;

    return (
        <button onClick={()=>props.onCellClick(props.id)}
         style={style} className='cell'>{value}</button> 
 );
   
}; 

export default BoardCell