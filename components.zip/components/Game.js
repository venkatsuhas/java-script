import React from 'react'
import TicTacToeBoard from './Board'

function TicTacToeGame() {
    return <TicTacToeBoard/>
}

export default TicTacToeGame