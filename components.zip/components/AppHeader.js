import React from 'react'

function AppHeader() {
    return (
        <div>
            <h1>Tic Tac Toe Game</h1>
        </div>
    )
}

export default AppHeader