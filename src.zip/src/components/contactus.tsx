import React from 'react';
function ContactUs(){
    
    return(<>
        <div className="contactUs"><h3>Contact us</h3>
        <p>Phone no:XXXXXXXXXX<br/><br/>
        email:bookmanagement@gmail.com</p></div>
        
</>

    )
}
export default ContactUs
